﻿
namespace pokemon
{
    partial class SelectPokemon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMachamp = new System.Windows.Forms.Button();
            this.btnGengar = new System.Windows.Forms.Button();
            this.btnSnorlax = new System.Windows.Forms.Button();
            this.btnZapdos = new System.Windows.Forms.Button();
            this.btnCharizard = new System.Windows.Forms.Button();
            this.btnGyarados = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMachamp
            // 
            this.btnMachamp.Image = global::pokemon.Properties.Resources.machamp;
            this.btnMachamp.Location = new System.Drawing.Point(563, 336);
            this.btnMachamp.Name = "btnMachamp";
            this.btnMachamp.Size = new System.Drawing.Size(258, 240);
            this.btnMachamp.TabIndex = 5;
            this.btnMachamp.UseVisualStyleBackColor = true;
            this.btnMachamp.Click += new System.EventHandler(this.btnMachamp_Click);
            // 
            // btnGengar
            // 
            this.btnGengar.Image = global::pokemon.Properties.Resources.gengar;
            this.btnGengar.Location = new System.Drawing.Point(286, 336);
            this.btnGengar.Name = "btnGengar";
            this.btnGengar.Size = new System.Drawing.Size(258, 240);
            this.btnGengar.TabIndex = 4;
            this.btnGengar.UseVisualStyleBackColor = true;
            this.btnGengar.Click += new System.EventHandler(this.btnGengar_Click);
            // 
            // btnSnorlax
            // 
            this.btnSnorlax.Image = global::pokemon.Properties.Resources.snorlax;
            this.btnSnorlax.Location = new System.Drawing.Point(12, 336);
            this.btnSnorlax.Name = "btnSnorlax";
            this.btnSnorlax.Size = new System.Drawing.Size(258, 240);
            this.btnSnorlax.TabIndex = 3;
            this.btnSnorlax.UseVisualStyleBackColor = true;
            this.btnSnorlax.Click += new System.EventHandler(this.btnSnorlax_Click);
            // 
            // btnZapdos
            // 
            this.btnZapdos.Image = global::pokemon.Properties.Resources.zapdos;
            this.btnZapdos.Location = new System.Drawing.Point(563, 75);
            this.btnZapdos.Name = "btnZapdos";
            this.btnZapdos.Size = new System.Drawing.Size(258, 240);
            this.btnZapdos.TabIndex = 2;
            this.btnZapdos.UseVisualStyleBackColor = true;
            this.btnZapdos.Click += new System.EventHandler(this.btnZapdos_Click);
            // 
            // btnCharizard
            // 
            this.btnCharizard.Image = global::pokemon.Properties.Resources.charizard;
            this.btnCharizard.Location = new System.Drawing.Point(286, 75);
            this.btnCharizard.Name = "btnCharizard";
            this.btnCharizard.Size = new System.Drawing.Size(258, 240);
            this.btnCharizard.TabIndex = 1;
            this.btnCharizard.UseVisualStyleBackColor = true;
            this.btnCharizard.Click += new System.EventHandler(this.btnCharizard_Click);
            // 
            // btnGyarados
            // 
            this.btnGyarados.Image = global::pokemon.Properties.Resources.gyarados;
            this.btnGyarados.Location = new System.Drawing.Point(12, 75);
            this.btnGyarados.Name = "btnGyarados";
            this.btnGyarados.Size = new System.Drawing.Size(258, 240);
            this.btnGyarados.TabIndex = 0;
            this.btnGyarados.UseVisualStyleBackColor = true;
            this.btnGyarados.Click += new System.EventHandler(this.btnGyarados_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(280, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 35);
            this.label1.TabIndex = 6;
            this.label1.Text = "Choose 3 Pokémon";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 597);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnMachamp);
            this.Controls.Add(this.btnGengar);
            this.Controls.Add(this.btnSnorlax);
            this.Controls.Add(this.btnZapdos);
            this.Controls.Add(this.btnCharizard);
            this.Controls.Add(this.btnGyarados);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnGyarados;
        private System.Windows.Forms.Button btnCharizard;
        private System.Windows.Forms.Button btnZapdos;
        private System.Windows.Forms.Button btnSnorlax;
        private System.Windows.Forms.Button btnGengar;
        private System.Windows.Forms.Button btnMachamp;
        private System.Windows.Forms.Label label1;
    }
}

