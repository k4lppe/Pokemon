﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pokemon
{
    public partial class SelectPokemon : Form
    {
        public SelectPokemon()
        {
            InitializeComponent();
        }

        private static int pokemonSelected = 0;


        private void btnGyarados_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonGyarados = new Pokemon("Gyarados","Water", "Flying", 95, 125, 79, 81);
            btnGyarados.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
               
            }
        }

        private void btnCharizard_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonCharizard = new Pokemon("Charizard", "Fire", "Flying", 78, 84, 78, 100);
            btnCharizard.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
                

            }
        }

        private void btnZapdos_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonZapdos = new Pokemon("Zapdos", "Electric", "Flying", 90, 90, 85, 100);
            btnZapdos.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
            }
        }

        private void btnSnorlax_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonSnorlax = new Pokemon("Snorlax", "Normal", "", 160, 110, 65, 30);
            btnSnorlax.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
            }

        }
        private void btnGengar_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonGengar = new Pokemon("Gengar", "Ghost", "Poison", 60, 65, 60, 110);
            btnGengar.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
            }


        }
        private void btnMachamp_Click(object sender, EventArgs e)
        {
            //name, type, type2, hp, attack, defence, speed
            Pokemon pokemonMachamp = new Pokemon("Machamp", "Fighting", "", 90, 130, 80, 55);
            btnMachamp.Enabled = false;
            pokemonSelected++;
            if (pokemonSelected >= 3)
            {
                MessageBox.Show("Starting game");
                Form2 BattleScreen = new Form2();
                BattleScreen.ShowDialog();
                   
            }
            

        }
    }
    public class Pokemon
    {

        public string pokemonName;
        public int pokemonHealth;
        public string pokemonType;
        public string pokemonType2;
        public int defense;
        public int attack;
        public int speed;


        public Pokemon(string pokemonName, string pokemonType, string pokemonType2, int pokemonHealth, int attack, int defense, int speed)
        {
            this.pokemonName = pokemonName;
            this.pokemonHealth = pokemonHealth;
            this.pokemonType = pokemonType;
            this.pokemonType2 = pokemonType2;
            this.defense = defense;
            this.attack = attack;
            this.speed = speed;
        }
       
        


      
        
    }   
}
